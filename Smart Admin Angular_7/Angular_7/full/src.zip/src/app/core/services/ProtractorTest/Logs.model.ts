export class LogsModel {
    assertions: string;
    description: string;
    duration: string;
}