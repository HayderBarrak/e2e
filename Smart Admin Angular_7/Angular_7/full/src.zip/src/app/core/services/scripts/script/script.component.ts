// import { Component, OnInit } from '@angular/core';
//
// @Component({
//   selector: 'sa-script',
//   templateUrl: './script.component.html',
//   styleUrls: ['./script.component.css']
// })
// export class ScriptComponent implements OnInit {
//
//   constructor() { }
//
//   ngOnInit() {
//   }
//
// }
