import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-platform',
  templateUrl: './platform.component.html',
  styleUrls: ['./platform.component.css']
})
export class PlatformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
