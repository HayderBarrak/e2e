import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-social',
  templateUrl: './social.component.html',
})
export class SocialComponent implements OnInit {

  ngOnInit() {
  }

}
