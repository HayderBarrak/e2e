// import { Component, OnInit } from '@angular/core';
//
// @Component({
//   selector: 'app-orders',
//   templateUrl: './orders.component.html',
// })
// export class OrdersComponent implements OnInit {
//
//   constructor() { }
//
//   ngOnInit() {
//   }
//
// }
