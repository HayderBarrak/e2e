// import { Component, OnInit } from '@angular/core';
//
// @Component({
//   selector: 'sa-shopping-cart',
//   templateUrl: './shopping-cart.component.html',
//   styles: []
// })
// export class ShoppingCartComponent implements OnInit {
//
//   constructor() { }
//
//   ngOnInit() {
//   }
//
// }
