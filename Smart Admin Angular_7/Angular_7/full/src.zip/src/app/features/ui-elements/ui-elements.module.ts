import {NgModule} from "@angular/core";

import {routing} from './ui-elements.routing'

@NgModule({
  declarations: [
  ],
  imports: [
    routing,
  ],
  providers: [
  ],
})
export class UiElementsModule {

}
