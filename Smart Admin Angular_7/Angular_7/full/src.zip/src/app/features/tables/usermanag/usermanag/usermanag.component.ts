import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {UserModel} from "@app/shared/user/User.model";
import {UserService} from "@app/shared/user/user.service";
import {Router} from "@angular/router";
import {ToastrService} from "ngx-toastr";
import {NotificationService} from "@app/core/services";

@Component({
    selector: 'sa-usermanag',
    templateUrl: './usermanag.component.html',
    styleUrls: ['./usermanag.component.css']
})
export class UsermanagComponent implements OnInit {

    selected = [];
    temp = [];
    @ViewChild('myTable') table: any;
    @ViewChild('myTabledetails') table2: any;
    user: UserModel;
    rows: UserModel[] = [];
    isSaving: boolean;
    timeout: any;
    row: string;
    n: number = 1;
    search = "";
    page: string;
    pagesizelist: number[] = [10, 20, 30];
    itemsPerPage = 10;
    public loading = false;
    controls: any = {
        pageSize: 10,
        filter: '',
    }

    constructor(private userservice: UserService,
                private router: Router,
                private toastr: ToastrService,
                private notificationService: NotificationService,) {
    }

    ngOnInit() {
        this.loadall()
    }

    loadall() {
        this.loading = true;
        setTimeout(() => {
            this.userservice.query({
                page: 0,
                size: this.itemsPerPage,
                // sort: this.sort(),
                search: this.search

            }).subscribe(data => {
                this.rows = data;
                this.loading = false;
            })
        }, 2000);
    }

    updateFilter(event) {
        const val = event.target.value.toLowerCase();

        // filter our data
        const temp = this.temp.filter(function (d) {
            return !val || ['machinename', 'adresse'].some((field: any) => {
                return d[field].toLowerCase().indexOf(val) !== -1
            })
        });

        // update the rows
        this.rows = this.temp;
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
        setTimeout(() => {
            this.loadall();
        }, 7000);
    }

    onSelect({selected}) {
        console.log('Select Event', selected, this.selected);

        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);
    }

    onPage(event) {
        clearTimeout(this.timeout);
        this.timeout = setTimeout(() => {
            console.log('paged!', event);
        }, 100);
    }

    @Input() cssClasses: any = {
        sortAscending: 'fa fa-sort-up',
        sortDescending: 'fa fa-sort-down',
        pagerLeftArrow: 'fa  fa-angle-left',
        pagerRightArrow: 'fa fa-angle-right',
        pagerPrevious: 'fa fa-angle-double-left',
        pagerNext: 'fa fa-angle-double-right'
    };

    onDetailToggle(event) {
        console.log('Detail Toggled', event);
    }

    toggleExpandRow(row) {
        this.user = new UserModel();
        this.user = row;
        row.$$expanded = !row.$$expanded;
        console.log('Toggled Expand Row!', row);
        this.table.rowDetail.toggleExpandRow(row);
    }


}
