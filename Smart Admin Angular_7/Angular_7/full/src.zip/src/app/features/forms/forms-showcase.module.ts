import {NgModule} from "@angular/core";

import {routing} from "./forms-showcase.routing";

@NgModule({
  declarations: [
  ],
  imports: [
    routing,
  ],
  providers: [],
  entryComponents: []
})
export class FormsShowcaseModule {}

