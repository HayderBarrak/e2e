import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-dropzone-showcase',
  templateUrl: './dropzone-showcase.component.html',
})
export class DropzoneShowcaseComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
