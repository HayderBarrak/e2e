import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-form-plugins',
  templateUrl: './form-plugins.component.html',
})
export class FormPluginsComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

  noUiSliderValue = [264, 776];

}
