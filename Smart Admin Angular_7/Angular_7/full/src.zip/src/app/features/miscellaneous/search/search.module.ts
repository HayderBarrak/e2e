import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchRoutingModule } from './search-routing.module';
import { SearchComponent } from './search.component';
import { SmartadminLayoutModule } from '@app/shared/layout';
import { StatsModule } from '@app/shared/stats/stats.module';

@NgModule({
  imports: [
    CommonModule,
    SearchRoutingModule,


    SmartadminLayoutModule,
		StatsModule,
  ],
  declarations: [SearchComponent]
})
export class SearchModule { }
