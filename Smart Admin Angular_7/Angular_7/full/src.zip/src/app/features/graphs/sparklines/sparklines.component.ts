import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-sparklines',
  templateUrl: './sparklines.component.html',
})
export class SparklinesComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
