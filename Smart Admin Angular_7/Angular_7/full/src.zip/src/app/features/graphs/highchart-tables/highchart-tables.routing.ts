
import {ModuleWithProviders} from "@angular/core"
import { Routes, RouterModule } from '@angular/router';


export const highchartTablesRoutes: Routes = [  {
  path: '',

}];

export const highchartTablesRouting = RouterModule.forChild(highchartTablesRoutes);

