import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-easy-pie-charts',
  templateUrl: './easy-pie-charts.component.html',
})
export class EasyPieChartsComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
