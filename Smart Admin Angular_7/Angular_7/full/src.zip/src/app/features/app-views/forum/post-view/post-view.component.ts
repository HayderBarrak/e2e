import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-post-view',
  templateUrl: './post-view.component.html',
})
export class PostViewComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
