import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { IdeActions, IdeActionTypes } from './ide.actions';

@Injectable()
export class IdeEffects {

  // @Effect()
  // effect$ = this.actions$.ofType(IdeActionTypes.LoadIdes);

  // constructor(private actions$: Actions) {}
}
